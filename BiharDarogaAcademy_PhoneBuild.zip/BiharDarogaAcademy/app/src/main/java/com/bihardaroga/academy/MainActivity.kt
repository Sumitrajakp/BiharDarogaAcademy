package com.bihardaroga.academy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF102A43)
private val Blue = Color(0xFF1976D2)
private val Pale = Color(0xFFF2F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AcademyApp() }
    }
}

data class Lesson(val subject: String, val chapter: String, val topic: String, val done: Boolean = false)

@Composable
fun AcademyApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("academy_progress", 0) }
    var selectedTab by remember { mutableStateOf(0) }
    var completed by remember { mutableStateOf(prefs.getBoolean("lesson1_done", false)) }
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }

    val lessons = remember(completed) {
        listOf(
            Lesson("इतिहास", "प्राचीन भारत", "इतिहास का परिचय और स्रोत", completed),
            Lesson("भूगोल", "ब्रह्मांड एवं सौरमंडल", "सौरमंडल का परिचय"),
            Lesson("राजव्यवस्था", "भारतीय संविधान", "संविधान की प्रस्तावना"),
            Lesson("विज्ञान", "भौतिक विज्ञान", "मापन एवं SI इकाइयाँ"),
            Lesson("बिहार सामान्य ज्ञान", "बिहार परिचय", "बिहार का भौगोलिक परिचय"),
            Lesson("गणित", "संख्या पद्धति", "प्राकृतिक एवं पूर्ण संख्याएँ"),
            Lesson("रीजनिंग", "समानता", "शब्द एवं संख्या समानता"),
            Lesson("हिंदी", "व्याकरण", "संज्ञा और उसके भेद")
        )
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Blue, background = Pale)) {
        Scaffold(
            containerColor = Pale,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val labels = listOf("होम", "क्लास", "टेस्ट", "प्रोग्रेस")
                    val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Quiz, Icons.Default.Insights)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index; selectedLesson = null },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            if (selectedLesson != null) {
                LessonScreen(selectedLesson!!, completed) {
                    completed = true
                    prefs.edit().putBoolean("lesson1_done", true).apply()
                }
            } else {
                when (selectedTab) {
                    0 -> HomeScreen(
                        completed = completed,
                        onStart = { selectedTab = 1 },
                        onOpenCalendar = { selectedTab = 3 }
                    )
                    1 -> ClassesScreen(lessons) { selectedLesson = it }
                    2 -> QuizScreen()
                    else -> ProgressScreen(completed)
                }
            }
        }
    }
}

@Composable
fun Header() {
    Column(Modifier.fillMaxWidth().background(Navy).padding(20.dp)) {
        Text("BIHAR DAROGA ACADEMY", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text("आपकी तैयारी, आपकी सफलता", color = Color(0xFFD6E6F5), fontSize = 13.sp)
    }
}

@Composable
fun HomeScreen(completed: Boolean, onStart: () -> Unit, onOpenCalendar: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Header() }
        item {
            Column(Modifier.padding(16.dp)) {
                Text("नमस्ते, अभ्यर्थी! 👋", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("आज की पढ़ाई यहीं से शुरू करें।", color = Color.DarkGray)
                Spacer(Modifier.height(14.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("आज का लक्ष्य", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("1. एक बेसिक क्लास पूरी करें")
                        Text("2. 10 MCQ का अभ्यास करें")
                        Text("3. आज पढ़े हुए टॉपिक का रिवीजन करें")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                            Text("पढ़ाई शुरू करें")
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("क्लास पूरी", if (completed) "1" else "0", Modifier.weight(1f))
                    StatCard("आज का टेस्ट", "0/10", Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenCalendar() },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE5F1FF))
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Blue)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("स्टडी प्लान और प्रोग्रेस", fontWeight = FontWeight.Bold)
                            Text("अपनी पढ़ाई की स्थिति देखें", fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("मुख्य विषय", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("इतिहास • भूगोल • राजव्यवस्था • विज्ञान • गणित • हिंदी • रीजनिंग • बिहार GK", fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text("ऑफलाइन मोड: इस शुरुआती संस्करण की क्लास और टेस्ट बिना इंटरनेट चलेंगे।", fontSize = 12.sp, color = Color(0xFF52606D))
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 12.sp, color = Color.Gray)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        }
    }
}

@Composable
fun ClassesScreen(lessons: List<Lesson>, onSelect: (Lesson) -> Unit) {
    Column {
        Header()
        Text("विषयवार क्लास", Modifier.padding(16.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(lessons) { lesson ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(lesson) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = Blue)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(lesson.subject, fontWeight = FontWeight.Bold)
                            Text("${lesson.chapter} • ${lesson.topic}", fontSize = 12.sp, color = Color.DarkGray)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
fun LessonScreen(lesson: Lesson, completed: Boolean, onComplete: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Pale)) {
        Header()
        Column(Modifier.padding(18.dp)) {
            Text(lesson.subject, color = Blue, fontWeight = FontWeight.Bold)
            Text(lesson.chapter, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text(lesson.topic, fontSize = 17.sp)
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("क्लास 1: परिचय", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("इस पाठ में विषय की बुनियादी जानकारी पढ़ें। पहले परिभाषा समझें, फिर मुख्य तथ्य याद करें और अंत में प्रश्नों से अभ्यास करें।")
                    Spacer(Modifier.height(12.dp))
                    Text("पढ़ने का तरीका", fontWeight = FontWeight.Bold)
                    Text("• पहले कॉन्सेप्ट समझें\n• महत्वपूर्ण शब्द नोट करें\n• उदाहरणों से अभ्यास करें\n• अंत में MCQ हल करें")
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onComplete, modifier = Modifier.fillMaxWidth(), enabled = !completed) {
                Text(if (completed) "क्लास पूरी हो चुकी है ✓" else "क्लास पूरी करें")
            }
            Text("नोट: यह MVP डेमो पाठ है। अगले संस्करण में पूरा प्रमाणित चैप्टर कंटेंट जोड़ा जाएगा।", Modifier.padding(top = 12.dp), fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun QuizScreen() {
    var answer by remember { mutableStateOf<String?>(null) }
    val correct = "केल्विन"
    Column(Modifier.fillMaxSize()) {
        Header()
        Column(Modifier.padding(18.dp)) {
            Text("आज का अभ्यास प्रश्न", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.height(16.dp))
            Text("तापमान की SI इकाई क्या है?", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            listOf("सेल्सियस", "फारेनहाइट", "केल्विन", "जूल").forEach { option ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { answer = option },
                    colors = CardDefaults.cardColors(
                        containerColor = if (answer == option) Color(0xFFE5F1FF) else Color.White
                    )
                ) {
                    Text(option, Modifier.padding(16.dp))
                }
            }
            if (answer != null) {
                val isCorrect = answer == correct
                Text(if (isCorrect) "सही जवाब! ✓" else "गलत जवाब। सही उत्तर: केल्विन", color = if (isCorrect) Color(0xFF16803C) else Color(0xFFB42318), fontWeight = FontWeight.Bold)
                Text("व्याख्या: तापमान की SI मूल इकाई केल्विन (K) है।", fontSize = 13.sp)
                TextButton(onClick = { answer = null }) { Text("दोबारा प्रयास करें") }
            }
        }
    }
}

@Composable
fun ProgressScreen(completed: Boolean) {
    Column {
        Header()
        Column(Modifier.padding(18.dp)) {
            Text("आपकी प्रोग्रेस", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.height(16.dp))
            StatCard("पूरी की गई डेमो क्लास", if (completed) "1" else "0")
            Spacer(Modifier.height(12.dp))
            Text("अगला लक्ष्य", fontWeight = FontWeight.Bold)
            Text("सभी विषयों की बेसिक क्लास पूरी करना")
            Spacer(Modifier.height(12.dp))
            Text("आपकी प्रोग्रेस इसी मोबाइल में सेव होती है। ऐप बंद करने के बाद भी क्लास की स्थिति बनी रहेगी।", fontSize = 13.sp, color = Color.DarkGray)
        }
    }
}
